<?php
/**
*used to include function
*/
    include_once 'definer.php';
    include_once 'show.php';
	include_once 'database.php';
	include_once 'download.php';
	//include_once 'sessions.php';