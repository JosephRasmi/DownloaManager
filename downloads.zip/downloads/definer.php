<?php
// for definig this manager constants

// main function used to handle all the trnsaction done with the download.
//mailing system

@define(SYSTEM_MANAGER_MAIL, "lordcommander001@gmail.com");
@define(SYSTEM_MAIL, "chachajoseph109@gamil.com");