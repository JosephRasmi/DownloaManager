<?php
function set_session($_sid, $string)
{
    global $mysqli;
    $query = "INSERT INTO mysessions (sid,value) VALUES (?,?) ON DUPLICATE KEY UPDATE value = ?";
    
    $db = $mysqli->stmt_init();
    $db->prepare($query);
    $db->bind_param("sss", $_sid, $string, $string);
    $db->execute();
    echo '<hr> the affected row include'.$db->affected_rows;
}


function get_sessions($_sid){
    global $mysqli;
    $query = "SELECT value FROM mysessions WHERE sid=?";
    $db = $mysqli->stmt_init();
    $db->prepare($query);
    $db->bind_result($string);
    $db->store_result();
    $db->fetch();
    
    return $string;
}
