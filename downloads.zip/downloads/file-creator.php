<?php
// this file may be a stand alone or incoporated in the file that require it
// should be kept away from access i.e not in public directories
// pass it an array of file from post that need be created its data
include 'FileData.php';

function file_data($file_id_array, &$cost){
    // array to hold file data for download accessable throughout therefore one returned
    $file_data_array = array();
    global $mysqli;
    $cost = 0.00;
    
    //database details that will be used 
    $query = "SELECT storage,charges FROM Files WHERE file_id=?";
    $database = $mysqli->stmt_init();
    $database->prepare($query);
   
    
    foreach ($file_id_array as $file_id){
        // create file object for further use
        $fileData = new FileData($file_id);
        
        //cost for all files set it to zero before toping it up.
        
        $database->bind_param("d", $file_id);
        $database->execute();
        $database->bind_result($filepath, $fees);
        $database->store_result();
        

        if($database->num_rows==1){
            // file exist and in good state.
            //create download deatails for that file.
            $database->fetch();
            $file_name = basename($filepath);
            $fileData->setFileCorrupt($fileData::FILE_OK);
            $fileData->setFileName($file_name);
            $fileData->setFileAmt($fees);
            $fileData->SetFilePath($filepath);
            $cost += $fees;
            $fileData->setFileName($file_name);
            $fileData->SetFilePath($filepath);
            
    //add to array for further use.
    $file_data_array["$file_name"] = $fileData;
        }
        //else there was an error obtaining the file. which could be
        // 1.malicous act of a user
        // 2.data in inconsitency state
        // or file key does not exist but data supplied is set
        // therefore mail error and id to system manager for examination
        else {
            include_once 'mail.php';
          // TEMPORARY  
           echo '<hr/> '.$mail.'<hr/>';
        }
  
} 
// everything got as planned 

return $file_data_array;
}











