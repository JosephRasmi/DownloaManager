<?php
// used to handle file download. only involved if reffered to it by download handler 
//else there if a very serious violation of system management
require_once 'download.php';
include_once 'includer.php';
session_start();
//variable data and there defaults
$range = FALSE;
$fileId = isset($_GET['id']) ? $_GET['id'] : false;
$filepath = $_SESSION[$fileId];
 
  //handle range only
if((isset($_SERVER['HTTP_RANGE']))){
    $range = TRUE;
    
    if ($fileId){
        if(is_file($filepath)) goto download;
        else goto fileError;
    }
    
    else goto idError;
}

if(isset($_SERVER['HTTP_REFERER'])){
    
    $referer = strrchr($_SERVER['HTTP_REFERER'], '/');
   
       if((strcasecmp($referer, '/index.php'))==0){
   
           // check whether user trying to play save by removing changing user id            
             if($fileId){
                        
                        if(is_file($filepath))
                           goto download;
                        
                        // is like the file doesn't exist. mail too
                            else goto fileError;
             }
        
            //file id changed, deny
            else goto idError;
        }
             
  // referer corrupted or not set, deny
  else echo 'Access denied. contant our <a href ="mailto:'.SYSTEM_MANAGER_MAIL.'">Web Master</a>';
        
}
// copy pasting of link, deny
else echo '<hr>Access denied. contant our <a href ="mailto:'.SYSTEM_MANAGER_MAIL.'">Web Master</a>';

download:   download($filepath, $range, $fileId);
fileError:  {
                header("HTTP/1.1 404 Not Found");
                 $mail = "The following had a problem
                                  <li>$fileId
                                   <li>$filepath";
                                   $mail = wordwrap($mail,70,'\r\n');
                                   @mail(SYSTEM_MANAGER_MAIL,"FILE ID", "<hr/>$mail<hr/>","FROM:".SYSTEM_MAIL);}

                
idError:    echo 'Access denied. contant our <a href ="mailto:'.SYSTEM_MANAGER_MAIL.'">Web Master</a>';






