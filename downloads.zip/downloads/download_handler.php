<?php
// store this file away from root directory for better
echo '<hr> <h3 style = "text-align:center">HERE ARE YOUR FILES:</h3><dd>Click the following file names to download your files</dd><p><ul>';
foreach ($file_created as $myfile){
    if($myfile->getFilecCorrupt()==FileData::DEFAULT_FILE_MESSAGE){
        echo "this should be mailed: {$myfile->getFilecCorrupt()}";
    }
    else {
        // everything right
        $file_id = $myfile->randomId();
        $file_name = $myfile->getFileName();
        $len_ex = @strlen(strstr($file_name, '.'));
        $dotpos = @strlen($file_name)-$len_ex;
        $file_name = @substr($file_name, 0, $dotpos);
       
        
        $_SESSION[$file_id] = $myfile->getFilePath();
    
       @printf("<li><a href=\"filemanager.php?id=%s\">%s</a></li>", $file_id, $file_name);
    }
    
}
session_encode();