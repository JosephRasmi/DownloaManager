<?php
// This file contain information that will be mailed to system admin if something went wrong when a file was being accessed from the database
//define the global data to hold data like system mannager email, system mail account etc.

//main but will be commented for develelopment purposes.
$user_ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$user_sid_ = session_id();
$user_address = $_SERVER['REMOTE_ADDR'];
if(isset($_SERVER['USER_MAIL'])|(!empty($_SERVER['USER_MAIL'])))$user_mail = $_SERVER['USER_EMAIL'];
else $user_mail = 'user email was not provided';
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=iso-8859-1';
$headers[] = 'From:'.SYSTEM_MAIL;
$headers[] = 'To:'.SYSTEM_MANAGER_MAIL;
$mail = '<DOCKTYPE html>
    
<style type="text/css">.heading{ color:blue;font-decoration:underline; }
em{ color:red;}</style>
<p>The following file id had a problem while trying to be extracted from the system:</p>
<strong>File Id=><em>'.$file_id.'</em></strong>.
<br/><span class="heading">Which could be:</span>
<p><ol><li>Malicous act of a user
<li>Data in inconsitency state or
<li>File key does not exist but data supplied is set</li>
</ol></p>
<br/><span class="heading">The user details that got involved include:</span></p>
<ul><li>User Agent: <em>'.$user_agent.'</em>
<li>Session Id: <em>'.$user_sid_.'</em>
<li>User email: <em>'.$user_mail.'</em>
<li>User IP address: <em>'.$user_ip.'</em></li>
<h2 style="font-size:large"><strong>Please do something</strong></h2>';

@wordwrap($mail, 70, '\r\n');
$mail = str_replace('CRLF', 'LF', $mail);

//@mail('chachajoseph109@gmail.com', 'sub', $mail);
 // uncomment
$ab = @mail(SYSTEM_MANAGER_MAIL,"FILE CREATION", "<hr/>$mail<hr/>", implode("\r\n", $headers));
if(!$ab) echo 'false mail not send';