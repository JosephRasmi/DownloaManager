<?php

/**
* used to connect to the database
* for security reasons save it outside the root directory
* create a file text where the connection details will be saved and edited regularly
*
*/
$host = "localhost";
$user = "xerxesj";
$pass = "12qwaszx";
$database = "schoolsnet";
$mysqli = new mysqli($host,$user,$pass,$database);
$database = $mysqli->stmt_init();
if(mysqli_connect_errno()){
		//something happened mail it to admin
		//log error or mail it to admin
		echo "database base check ".mysqli_connect_error(); // temp used to check database conectivity before anything continoues
	exit;
	}
