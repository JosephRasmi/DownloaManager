<?php
/**
* used to handle file downloads provided a file path
* store it outside the root directory for security reasons
*/

function download(string $filepath, bool $range, $fileId){
	// to avoid compression turn off.
	@apache_setenv('no-gzip', 1);
    @ini_set('zlib.output_compression', 'Off');
   
	
    $pathinfo = pathinfo($filepath);
$file_ext = $pathinfo['extension'];
$file_name = $file_name  = $pathinfo['basename']; 
$file_size = filesize($filepath);
$file_start; $file_end;
$file = @fopen($filepath, 'r');
if($range) include_once 'range-set.php';

else {
//For content type
$content_default = "text/rtf";
$cont_type = array (
			"pdf"=>"application/pdf",
			"ppt"=>"application/vnd.ms-powerpoint",
			"zip"=>"application/zip",
			"xls"=>"application/vnd.ms-excel",
            "mp3" => "audio/mpeg",  
            "mp4" => "video/mpeg",
            "mpg" => "video/mpeg",
            "avi" => "video/x-msvideo",
			);
		
		//content type sent to user
		$to_use = isset($cont_type["$file_ext"]) ? ($cont_type["$file_ext"]) : $content_default;
		
        // set the headers, prevent caching
		header("Pragma: public");
		header("Expires: -1");
		header("Cache-Control: public, must-revalidate, post-check=0, pre-check=0");
		header("Content-Disposition: attachment; filename=\"$file_name\"");
		header("Content-Type: $to_use");
		header("Content-Length: $file_size");
		
}
		ob_flush();
		flush();
		
		readfile($filepath);
    
		if(!connection_status()){
		    @fclose($file);
		    exit;
		}
	@fclose($file);
	unset($_SESSION[$fileId]);
	
	return true;
			
} 