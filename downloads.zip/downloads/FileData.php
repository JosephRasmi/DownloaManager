<?php
// this class is only associated with function file_array for creating an array of file data to be downloaded so know how
// to handle it.

class FileData
{
     CONST DEFAULT_FILE_AMT = 0.00;
     CONST DEFAULT_FILE_PATH = 'UNKNOWN';
     CONST DEFAULT_FILE_NAME = 'UNKNOWN';
     CONST DEFAULT_FILE_MESSAGE = 'THERE IS CORRUPTION WITH THIS FILE';
     CONST FILE_OK = 'OK: FOUND IN THE DATABASE';
    
   private $file_id;
   private $amt;
   private $file_path;
   private $file_name;
   private $message;
   private $random_id;

    public function __construct(int $file_id)
    {
        $this->file_id = $file_id;
        $this->setFileName(FileData::DEFAULT_FILE_NAME);
        $this->setFileAmt(FileData::DEFAULT_FILE_AMT);
        $this->setFilePath(FileData::DEFAULT_FILE_PATH);
        $this->setFileCorrupt(FileData::DEFAULT_FILE_MESSAGE);
        $this->random_id = 0;
    }
    public function setFileAmt(float $amt){
            $this->amt = $amt;

    }
    public function setFilePath(string $file_path){
            $this->file_path = $file_path;
       
    }
    public function getFileId(){
        return $this->file_id;
    }
    public function getFilePath(){
        return $this->file_path;
    }
    public function getAmt(){
        return $this->amt;
    }
    public function setFileName(string $file_name){
            $this->file_name = $file_name;
       
    }
    public function getFileName(){
        return $this->file_name;
    }
    // message sent to the user if file corruption exists
    // else OK is returned
    public function setFileCorrupt($message){
      $this->message = $message;
     
    }
    // get the message
    public function getFilecCorrupt(){
        return $this->message;
    }
    //create a random id for security reasons
    public function randomId(){
        $this->random_id = bin2hex(random_bytes(6));
        return $this->random_id;
    }
}

