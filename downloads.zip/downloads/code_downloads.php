<?php
/**
 * used to handle downloads by users who have not subscribed or who prefer to use mobile money code
 * store this file away from accessable directory if possibble
 */

require_once 'file-creator.php';

//used to hold file id supplied by the user.
//and check whether the file name is supplied usin show function
//$file_id = isset($_POST['file_id'])?$_POST['file_id']:show('filename');

// verify and access the supplied file data
$file_id_array = array($_POST['file1'], $_POST['file2'], $_POST['file3']);

// to hold the amount for the as obtained from the database.
$cost;

// get file data
$file_created = file_data($file_id_array, $cost);
//$index = array_keys($file_created);
//$file = $index[0];
//print "the following file id was found with inconsistency {$file_created[$file]->getFileId()} therefore {$file_created[$file]->getFilecCorrupt()}";

if($cost == 0.00){
    // user trying to access free files
echo 'the files you are trying to access are absolutely free. your downloads will start immediately. <br <br />';
print '<h1 style="text-align:center"><b>ENJOY !!!!!!!</b></h1><hr/>';
    // get files for the files
    include_once 'download_handler.php';
}
else {
        //file are chargable process payment 
        $code = (isset($_POST['code']) & !empty($_POST['code'])) ? $_POST['code'] : show('The Transaction code');
        include_once 'paid.php';
}
  