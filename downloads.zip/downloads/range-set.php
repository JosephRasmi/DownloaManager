<?php
 // used to set the seek start and seek end of a file if a download is resumed.

    list($si_unit, $range_starts) = explode('=', $_SERVER['HTTP_RANGE'], 2);
        if($si_unit == 'bytes'){
            list($range1, $range2) = explode(',', $range_starts, 2);
    
          }
      else
    {
         $range1 = '';
            header('HTTP/1.1 416 Requested Range Not Satisfiable');
               exit;
    }
list($file_start,$file_end) = explode('-', $range1, 2);

$file_end   = (empty($file_end)) ? ($file_size - 1) : min(abs(intval($file_end)),($file_size - 1));
$file_start = (empty($file_start) || $file_end < abs(intval($file_start))) ? 0 : max(abs(intval($file_start)),0);


if ($file_start > 0 || $file_end < ($file_size - 1))
{
    header('HTTP/1.1 206 Partial Content');
    header('Content-Range: bytes '.$file_start.'-'.$file_end.'/'.$file_size);
    $file_size = $file_end - $file_start + 1;
    fseek($file, $file_start);
    header("Content-Length: $file_size");
}
