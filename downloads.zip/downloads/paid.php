<?php
$query = "SELECT amt FROM Transactions WHERE trans_id=?";
$database->prepare($query);
$database->bind_param("s", $code);
$database->execute();
$database->bind_result($amt);

if($database->fetch()){

   if($amt<$cost)
        printf("please add the Ksh. %d then retry using the most recent code", $cost-$amt);
        // add more code too handle pending downloads
        elseif ($cost<$amt){
            printf("It seems you have paid extra amount for the files request of Ksh. %d ", $amt-$cost);
            echo '.If you dont want lose add more files or subscribe to save your money';
            // write code to process this.
        }
        
      else  {
            echo 'here we are you have paid : '.$amt; //include_once 'download_handler.php';
            echo '<dd>Transaction succeed: wait as we provide you a link for you downloads</dd>';
            echo '<div style="width:50%; height:200px"; text-align:center; position:relative; margin-left:200px; float:right>';
            echo '<h1>PUT HERE SOME ANIMATION AS FILES FOR USER ARE PROCESSED AND MAKE DELAY FOR SOME SECONDS</h1></div>';
            include_once 'download_handler.php';
        }
      
}

else {
    echo 'Transaction failed:<dl>';
    echo "<dd>Please check and renter the code or wait for a while because we may not have received payments from your mobile banker</dd></dl>";
    echo 'but this one must be first retried by Javascript before informing the user';
}

