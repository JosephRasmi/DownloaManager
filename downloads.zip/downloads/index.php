<?php


require_once 'includer.php';

session_cache_limiter('private');
session_start();

// edit this to reflect no of files selected
if(isset($_POST['file1']) & !(empty($_POST['file1']))){
    // then is a brand new download
    include_once 'code_downloads.php';
    
}
    else echo 'Ok!!!!! john is reali disturbing na maconcubines wako';

if(isset($_SERVER['HTTP_RANGE'])){
    // then user is trying to access a resumed incomplete download due to connection failer or paused download.
    echo 'range is set les process it';
    
}
