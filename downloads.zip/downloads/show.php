<?php
/**used to inform the user the content not supplied
 * 
 * @param string $param
 * @return void
 */
function show($param){
    if($param=="filename") echo "Dont try this!";
        else {echo "provide $param";
		echo "<br /> and retry:";} 
 exit; 
}