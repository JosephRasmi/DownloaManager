<?php



/*session_start();
$username = 'joseph';
$_SESSION[$username] = "Jason";
$user = $_SESSION[$username];
if($user)printf("Your username is %s.", $_SESSION[$username]);

$file_id = 'id';
 $_SESSION[$file_id] = 'i dont know what could be wrong';
        
        $filepath = $_SESSION[$file_id];
        if($filepath) echo 'everything ok, file path is ok, file path = '.$filepath;
session_destroy();
//else echo "database found with".$database->error;*/
/*if($bytes = random_bytes(5)){
$x = 5;
echo 'the dump is'.bin2hex($bytes);}
echo '      '.$x;*/

$var2;
$var1 = $_POST['password'];
//$var2 = $_POST['phone_no'];

if( isset($_GET['phone_no'])){
$var2 = $_GET['phone_no'];
echo "you used phone no. Its value is $var2";}
else if (isset($_GET['emailAddress'])){
$var2 = $_GET['emailAddress'];
echo "You used an EmailAddress. Its value is $var2";}
else if (isset($_GET['id'])){
$var2 = $_GET['id'];
echo "for sure you used your national identity. Its value is $var2";}

echo "  and your password is $var1 <br><hr>";

//for($var =3; $var < 6; $var++){
// $var = "var" + $var;
 $var1= $_POST['emailAddress'];
echo "other values are = $var1 ";
//}
//$s = $_GET['id'];
//echo"anything that make sense is the game of love<brbrbrbrbrb> $s";
//foreach($_POST as $post){
//echo "{$post} + noma sana<br>";}
