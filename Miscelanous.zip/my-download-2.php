<?php
/**
* used to handle file downloads provided a file path
* store it outside the root directory for security reasons
*/
download("Action Movies Jet Li Fist of Legend 1994 Jet Li HD(1).mp4");
function download(string $filepath){
	// to avoid compression turn off.
	@apache_setenv('no-gzip', 1);
    @ini_set('zlib.output_compression', 'Off');
	$pathinfo = pathinfo($filepath);
$file_ext = $pathinfo['extension'];
$file_name = $file_name  = $pathinfo['basename']; 
$file_size = filesize($filepath);

//For content type
$content_default = "video/mpeg";
$cont_type = array (
			"pdf"=>"application/pdf",
			"ppt"=>"application/vnd.ms-powerpoint",
			"zip"=>"application/zip",
			"xls"=>"application/vnd.ms-excel",
			);
		//content type sent to user
		$to_use = isset($cont_type["$file_ext"])?($cont_type["$file_ext"]):$content_default;
// set the headers, prevent caching
		header('Content-Description: File Transfer');
		header("Pragma: public");
		header("Expires: -1");
		header("Cache-Control: public, must-revalidate, post-check=0, pre-check=0");
		header('Content-Disposition: attachment; filename="aaa.mp4"');
		//header("Content-Length: $file_size");
		header("Content-Type: $to_use");
		header('Accept-Ranges: bytes');
		 header("Content-Length: $file_size");
		
		ob_flush();
		flush();
	//upto here everyhnig is okay read file
if(isset($_SERVER['HTTP_RANGE'])){
	list($units, $ranges) = explode('=', $_SERVER['HTTP_RANGE'], 2);


	if ($units == 'bytes')
			{
				//multiple ranges could be specified at the same time, but for simplicity only serve the first range
				
				list($range, $extra_ranges) = explode(',', $ranges, 2);
			}
			else
			{
				$range = '';
				header('HTTP/1.1 416 Requested Range Not Satisfiable');
				exit();
			}
		//figure out download piece from range (if set)
		list($seek_start, $seek_end) = explode('-', $range, 2);
		//set start and end based on range (if set), else set defaults
		//also check for invalid ranges.
		$seek_end   = (empty($seek_end)) ? ($file_size - 1) : min(abs(intval($seek_end)),($file_size - 1));
		$seek_start = (empty($seek_start) || $seek_end < abs(intval($seek_start))) ? 0 : max(abs(intval($seek_start)),0);
if ($seek_start > 0 || $seek_end < ($file_size - 1))
		{
			header('HTTP/1.1 206 Partial Content');
			header('Content-Range: bytes '.$seek_start.'-'.$seek_end.'/'.$file_size);
			header('Content-Length: '.($seek_end - $seek_start + 1));
		}
else
		  header("Content-Length: $file_size");
fseek($file, $seek_start);
}
	readfile($filepath);
} 
