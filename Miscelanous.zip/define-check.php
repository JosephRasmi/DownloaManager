<?php
include_once(dirname(__FILE__)."/define.php");
echo BOY+GIRL+$non_cons;
$data = array ();
$pfiancee = "Mercy";
$category = "girlfriend";
//array_unshift($data, array("$pfiancee"=>"girlfriend"));
$data["$category"] = $pfiancee;
print_r($data);
vprintf("<hr/>my prospecting fiancee name is %s. <em>I have a stronger feeling to that girl</em><br>",$data);
print("<b>my crash on her is too much</b>");

$sake=basename('/jfjjs/jjsdkk/kk-dk.txt');

echo '---> girl for your sake inclusive i do this '.$sake.'<hr>';
$data["$sake"]="meaning";
print_r($data);
echo "-----><br><pre>\t\t<b>{$data["$sake"]}</b> =>is the programming shit i transnight doing";
