<?php
echo get_include_path();

// Or using ini_get()
echo "<br />".ini_get('include_path');
?>


