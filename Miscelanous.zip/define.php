<?php

define('BOY',5);
define('GIRL',6);
//CONST $MAN=5;
$non_cons=6;
tria();
//@ini_set('display_errors','off');





function tria(){
             
	echo " echo to try the trial <br />".$GLOBALS['non_cons'];
}
