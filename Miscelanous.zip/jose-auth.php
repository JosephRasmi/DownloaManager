<?php
echo "Your supplied username: {$_SERVER['PHP_AUTH_USER']}<br />";
echo "Your password: {$_SERVER['PHP_AUTH_PW']}<br />"; 
//header('WWW-Authenticate: Basic Realm= "Authentication"');
header("HTTP/1.1 401 Unauthorized");
echo md5("jose")."<br/>";
echo md5("jose")."<br/>";
echo md5("jose")."<br/>";

/*// Check password for guessability
$check = crack_check($dictionary, $pswd);
// Retrieve outcome
echo crack_getlastmessage();
// Close dictionary
crack_closedict($dictionary);*/
$mysqli=new mysqli();
$mysqli->mysqli_connect_error('localhost', 'root', 'mwitajose', 'mysql');
//echo $mysqli->error;
echo "jfakgncvnakkfjvnvnaka";
