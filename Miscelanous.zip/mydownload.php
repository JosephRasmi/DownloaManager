<?php
/* does not work with resumed downloads*/
/* Connecting, selecting database */
$file_path='./Action Movies Jet Li Fist of Legend 1994 Jet Li HD(1).mp4';
$file = @fopen($file_path,"rb");
$file_size  = filesize($file_path);
header('Content-Disposition: attachment; filename="downloaded.mp4"');
//header('Content-Length: 868777666');change this
header('Content-Type: video/mp4');
if(isset($_SERVER['HTTP_RANGE'])){
			list($size_unit, $range_orig) = explode('=', $_SERVER['HTTP_RANGE'], 2);
			if ($size_unit == 'bytes')
			
	{ list($range, $extra_ranges) = explode(',', $range_orig, 2);
}
			else
			{
				$range = '';
				header('HTTP/1.1 416 Requested Range Not Satisfiable');
				exit;
			}
		}
else
		{
			$range = '';
		}
list($seek_start, $seek_end) = explode('-', $range, 2);

$seek_end   = (empty($seek_end)) ? ($file_size - 1) : min(abs(intval($seek_end)),($file_size - 1));
$seek_start = (empty($seek_start) || $seek_end < abs(intval($seek_start))) ? 0 : max(abs(intval($seek_start)),0);

 header("Content-Length: $file_size");

		header('Accept-Ranges: bytes');
    
		set_time_limit(0);
		fseek($file, $seek_start);
		
		while(!feof($file)) 
		{
			print(@fread($file, 1024*8));
			ob_flush();
			flush();
			if (connection_status()!=0) 
			{
				@fclose($file);
				exit;
			}			
		}
	 
@fclose($file);
		exit;
//ob_flush();
//flush();
//$byte = readfile('./Watch Bazodee for Free on 123movies.org.mp4')
 ?>
<p>your DOWNLOd hS ATEssd</p>


